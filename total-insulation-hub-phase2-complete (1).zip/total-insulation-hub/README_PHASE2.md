# Total Insulation Hub — Phase 2

Adds the Business module: Tenders, WIP Projects, Variations, and Documents.

## What's included

- Tenders: list with search and status filter, detail view with notes popup,
  outstanding items checklist, Procore/OneDrive links, status change, create
  new tender form
- WIP Projects: list with search, detail view showing budget vs actual,
  crew assigned, related variations, Procore/OneDrive links
- Variations: list with status filter, approve/reject/complete actions
- Documents: simple browser of OneDrive and Procore links pulled from your
  tenders and projects
- All of it is realtime — if you update a tender on one device, it updates
  everywhere else instantly
- Import scripts to bulk-load your existing Tender_List.xlsx and WIP Excel
  files into Supabase

## Files to add/replace in your GitHub repo

Copy everything from this zip into the matching folders in your repo:

- `src/pages/Business/` (new folder — TendersList, TenderDetail,
  TenderCreate, WipProjectsList, VariationsList, DocumentsList,
  BusinessHome)
- `src/hooks/useTenders.ts` (new)
- `src/hooks/useWipProjects.ts` (new)
- `src/hooks/useVariations.ts` (new)
- `src/App.tsx` (replace — now routes to the real Business module)
- `scripts/import-tenders.js` (new)
- `scripts/import-wip.js` (new)
- `package.json` (replace — added the `xlsx` package for the import
  scripts)

Commit and push. Netlify will redeploy automatically.

## Importing your existing data

These two scripts run on your own computer (not in the app) because they
need a more powerful key than the app is allowed to use.

### 1. Get your service role key

In Supabase: Project Settings > API > copy the `service_role` key. Keep
this private — never put it in the app itself or in GitHub.

### 2. Install Node.js dependencies locally

```bash
cd total-insulation-hub
npm install
```

### 3. Set the two environment variables in your terminal

```bash
export SUPABASE_URL=https://tyzinzllfuufbqbkcutm.supabase.co
export SUPABASE_SERVICE_ROLE_KEY=paste-your-service-role-key-here
```

(On Windows, use `set` instead of `export`.)

### 4. Run the imports

```bash
node scripts/import-tenders.js "/path/to/Tender_List.xlsx"
node scripts/import-wip.js "/path/to/2026-27_WIP_-_Total_Insulation.xlsx"
```

Each script prints how many rows were inserted and how many were skipped
(skipped usually means a blank row or a project without a client/state).

### 5. Check the app

Log into the Hub, go to Business, and your real tenders and WIP projects
should now be listed.

## What's next (Phase 3)

Chat — channels by state, communities within each channel, job chats,
photo/document sharing — built into both the Hub and the Orders app.
