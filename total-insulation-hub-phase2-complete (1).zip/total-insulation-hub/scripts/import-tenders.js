/**
 * Imports your Tender_List.xlsx into the Supabase tenders table.
 *
 * Usage:
 *   node scripts/import-tenders.js path/to/Tender_List.xlsx
 *
 * Requires two environment variables to be set first:
 *   SUPABASE_URL=https://tyzinzllfuufbqbkcutm.supabase.co
 *   SUPABASE_SERVICE_ROLE_KEY=<service role key from Supabase API settings>
 *
 * The service role key is required (not the anon key) because this script
 * bypasses row level security to bulk-insert data. Never put the service
 * role key in the app itself — it's for one-off scripts like this only,
 * run from your own computer.
 */

import xlsx from 'xlsx';
import { createClient } from '@supabase/supabase-js';

const filePath = process.argv[2];
if (!filePath) {
  console.error('Usage: node scripts/import-tenders.js path/to/Tender_List.xlsx');
  process.exit(1);
}

const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceKey) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables first.');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceKey);

const STATUS_MAP = {
  Won: 'won',
  Completed: 'won',
  Live: 'submitted',
  Lost: 'lost',
  No: 'no_works',
};

function excelDateToISO(value) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === 'number') {
    // Excel serial date
    const date = xlsx.SSF.parse_date_code(value);
    if (!date) return null;
    const d = new Date(Date.UTC(date.y, date.m - 1, date.d));
    return d.toISOString().slice(0, 10);
  }
  const parsed = new Date(value);
  return isNaN(parsed.getTime()) ? null : parsed.toISOString().slice(0, 10);
}

async function run() {
  const workbook = xlsx.readFile(filePath);
  const sheetName = workbook.SheetNames.find((n) => n.includes('2026')) ?? workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];

  // Header row is row 4 in the source file (0-indexed row 3), matching the
  // structure discussed: STATUS, Due Date, Revised, Project, Companies,
  // STATE, Quote #, Value, Value Revision, Variation No., Variation Cost, Notes
  const rows = xlsx.utils.sheet_to_json(sheet, { range: 3, defval: null });

  let inserted = 0;
  let skipped = 0;

  for (const row of rows) {
    const projectName = row['Project'];
    if (!projectName) {
      skipped++;
      continue;
    }

    const rawStatus = (row['STATUS'] ?? '').toString().trim();
    const status = STATUS_MAP[rawStatus] ?? 'pending';
    const state = (row['STATE'] ?? '').toString().trim().toUpperCase();
    const validState = ['NSW', 'VIC', 'WA', 'QLD'].includes(state) ? state : null;

    const { error } = await supabase.from('tenders').insert({
      project_name: projectName.toString().trim(),
      client: (row['Companies'] ?? 'Unknown').toString().trim(),
      tender_number: row['Quote #'] ? row['Quote #'].toString() : null,
      state: validState,
      quoted_value: typeof row['Value'] === 'number' ? row['Value'] : null,
      revised_value: typeof row['Value Revision'] === 'number' ? row['Value Revision'] : null,
      due_date: excelDateToISO(row['Due Date']),
      status,
      notes: row['Notes'] ? row['Notes'].toString() : null,
    });

    if (error) {
      console.error(`Failed to insert "${projectName}":`, error.message);
      skipped++;
    } else {
      inserted++;
    }
  }

  console.log(`Done. Inserted ${inserted} tenders, skipped ${skipped}.`);
}

run();
