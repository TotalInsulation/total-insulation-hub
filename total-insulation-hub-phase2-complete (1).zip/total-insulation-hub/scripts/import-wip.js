/**
 * Imports your 2026-27 WIP Excel file into the Supabase wip_projects table.
 *
 * Usage:
 *   node scripts/import-wip.js path/to/2026-27_WIP_-_Total_Insulation.xlsx
 *
 * Same environment variables as import-tenders.js are required:
 *   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
 */

import xlsx from 'xlsx';
import { createClient } from '@supabase/supabase-js';

const filePath = process.argv[2];
if (!filePath) {
  console.error('Usage: node scripts/import-wip.js path/to/WIP.xlsx');
  process.exit(1);
}

const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceKey) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables first.');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceKey);

const STATE_MAP = {
  'New South Wales': 'NSW',
  Victoria: 'VIC',
  'Western Australia': 'WA',
  Queensland: 'QLD',
};

function excelDateToISO(value) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === 'number') {
    const date = xlsx.SSF.parse_date_code(value);
    if (!date) return null;
    const d = new Date(Date.UTC(date.y, date.m - 1, date.d));
    return d.toISOString().slice(0, 10);
  }
  const parsed = new Date(value);
  return isNaN(parsed.getTime()) ? null : parsed.toISOString().slice(0, 10);
}

async function run() {
  const workbook = xlsx.readFile(filePath);
  const sheetName = workbook.SheetNames.find((n) => n.toLowerCase().includes('july')) ?? workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const rows = xlsx.utils.sheet_to_json(sheet, { defval: null });

  let inserted = 0;
  let skipped = 0;

  for (const row of rows) {
    const projectName = row['Project Name'];
    if (!projectName) {
      skipped++;
      continue;
    }

    const rawState = (row['State'] ?? '').toString().trim();
    const state = STATE_MAP[rawState] ?? null;

    if (!state) {
      skipped++;
      continue;
    }

    const { error } = await supabase.from('wip_projects').insert({
      job_number: row['Job No.'] ? row['Job No.'].toString() : null,
      project_name: projectName.toString().trim(),
      client: (row['Client'] ?? 'Unknown').toString().trim(),
      state,
      quoted_value: typeof row['Project Value'] === 'number' ? row['Project Value'] : null,
      invoiced_to_date: typeof row['Inv to Date'] === 'number' ? row['Inv to Date'] : 0,
      start_date: excelDateToISO(row['Start Date']),
      planned_completion_date: excelDateToISO(row['Finish Date']),
      project_manager: row['Contracts Administrator or Project Manager']
        ? row['Contracts Administrator or Project Manager'].toString()
        : null,
      current_stage: 'Stage 1',
      completion_percentage: 0,
    });

    if (error) {
      console.error(`Failed to insert "${projectName}":`, error.message);
      skipped++;
    } else {
      inserted++;
    }
  }

  console.log(`Done. Inserted ${inserted} WIP projects, skipped ${skipped}.`);
}

run();
